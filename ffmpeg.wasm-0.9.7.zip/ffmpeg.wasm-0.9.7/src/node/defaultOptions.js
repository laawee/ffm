/*
 * Default options for node environment
 */
module.exports = {
  corePath: '@ffmpeg/core',
};
